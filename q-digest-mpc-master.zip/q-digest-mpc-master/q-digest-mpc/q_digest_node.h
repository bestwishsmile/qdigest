//
//

#ifndef Q_DIGEST_NODE_H
#define Q_DIGEST_NODE_H

#include "emp-tool/circuits/number.h"
#include "emp-tool/circuits/comparable.h"
#include "emp-tool/circuits/swappable.h"
#include "emp-tool/circuits/integer.h"
#include "emp-tool/circuits/bit.h"
#include <vector>
#include <bitset>
#include <algorithm>
#include <math.h>
#include <execinfo.h>
#include <string>

using std::string;
using std::min;
namespace emp {
    class QDigestNode : public Swappable<QDigestNode>, public Comparable<QDigestNode> {

    public:
        static int id_len;
    public:
        Integer id; //固定使用32长度的Integer, 使用长度为id_len长度的Integer
        Integer c; //固定使用32长度的Integer
        Bit isDummy;
        Bit isParent;

        QDigestNode();

        ~QDigestNode();

        QDigestNode(int64_t id, int c, bool is_Dummy, bool is_Parent, int party = PUBLIC);

        QDigestNode(const Integer &id, const Integer &c, const Bit &isDummy, const Bit &isParent);

        template<typename O>
        O reveal(int party = PUBLIC) const;

        //Comparable
        Bit geq(const QDigestNode &rhs) const;

        Bit equal(const QDigestNode &rhs) const;

        //Swappable
        QDigestNode select(const Bit &sel, const QDigestNode &rhs) const;

        QDigestNode operator^(const QDigestNode &rhs) const;
        
        QDigestNode operator^=(const QDigestNode &rhs);

        int size() const;

        QDigestNode operator+(const QDigestNode &rhs) const;

    };

    int QDigestNode::id_len = 32;

    // If(a,b,c) = a? b:c 可以通过select实现：
    // If(a,b,c) = c.select(a, b)
    QDigestNode IfThenElse_QNode(Bit &condition, const QDigestNode &res1, const QDigestNode &res2) {
        return res2.select(condition, res1);
    }

    Bit IfThenElse_Bit(Bit &condition, const Bit &res1, const Bit &res2) {
        return res2.select(condition, res1);
    }

    Integer IfThenElse_Integer(Bit &condition, const Integer &res1, const Integer &res2) {
        return res2.select(condition, res1);
    }

    //Swappable
    QDigestNode QDigestNode::select(const Bit &sel, const QDigestNode &rhs) const {
        QDigestNode res(*this);
        res.id = this->id.select(sel, rhs.id);
        res.c = this->c.select(sel, rhs.c);
        res.isDummy = this->isDummy.select(sel, rhs.isDummy);
        res.isParent = this->isParent.select(sel, rhs.isParent);
        return res;
    }

    QDigestNode QDigestNode::operator^(const QDigestNode &rhs) const {
        QDigestNode res(*this);
        res.id = this->id ^ rhs.id;
        res.c = this->c ^ rhs.c;
        res.isDummy = this->isDummy ^ rhs.isDummy;
        res.isParent = this->isParent ^ rhs.isParent;
        return res;
    }
    
    QDigestNode QDigestNode::operator^=(const QDigestNode &rhs) {
        this->id ^= rhs.id;
        this->c ^= rhs.c;
        this->isDummy ^= rhs.isDummy;
        this->isParent ^= rhs.isParent;
        return (*this);
    }

    //Comparable  // If(a,b,c) = a?b:c = c.select(a, b)
    /*这个是为OMerge设计的 （isDummy, -id，isParent）*/
/*    Bit QDigestNode::geq(const QDigestNode &rhs) const {
        //排序（isDummy, -id, isParent）isDummy升序，isDummy相同的按id降序，相同id的按 isParent升序
        //当前节点和后面的节点比较
        //返回false：交换，返回true 不交换
//        if (this->isDummy) {//如果当前是Dummy直接交换到后面，不用管rhs节点
//            res = false;
//        } else if (rhs.isDummy) {
//            res = true;
//        } else { //两个都不是Dummy的情况
//            if (this->id == rhs.id) { //id相同
//                res = !this->isParent; //如果当前节点为parent，直接交换
//            } else {
//                res = this->id >= rhs.id; //如果当前id更大就不交换,返回true；=无所谓，方便写mpc代码
//            }
//        }
        Bit bitTrue(true);
        Bit bitFalse(false);

        Bit res = bitTrue;
        Bit cond0 = this->id == rhs.id;
//cond 1-4必然有且只有一个成立
        Bit cond1 = this->isDummy;
        Bit cond2 = (!this->isDummy) & (rhs.isDummy);
        Bit cond3 = (!this->isDummy) & (!rhs.isDummy) & cond0;
        Bit cond4 = (!this->isDummy) & (!rhs.isDummy) & !cond0;

//        res = IF(cond1, bitFalse, res);
        res = res.select(cond1, bitFalse);
//        res = IF(cond2, bitTrue, res);
        res = res.select(cond2, bitTrue);
//        res = IF(cond3, !this->isParent, res);
        res = res.select(cond3, !this->isParent);
//        res = IF(cond4, this->id >= rhs.id, res);
        res = res.select(cond4, this->id >= rhs.id);

        return res;
    }*/

    /*这个是为OCheck设计的 （id, -isParent）*/
    Bit QDigestNode::geq(const QDigestNode &rhs) const {
        //排序（id, -isParent）id升序，id相同的节点中isParent降序
        //当前节点和后面的节点比较
        //返回false：交换，返回true 不交换
        Bit bitTrue(true);
        Bit bitFalse(false);

        Bit res = bitTrue;
//cond 1-2必然有且只有一个成立
        Bit cond1 = this->id == rhs.id;
        Bit cond2 = !cond1;

//        res = IF(cond1, !this->isParent, res); 如果id相等
        res = res.select(cond1, this->isParent);
//        res = IF(cond2, this->id >= rhs.id, res);如果id不相等
        res = res.select(cond2, rhs.id >= this->id);

        return res;
    }

    /*这个是为OCheck设计的 （isParent，-id）*/
/*    Bit QDigestNode::geq(const QDigestNode &rhs) const {
        //排序（isParent，-id）isParent升序，isParent相同的节点中 id降序
        //当前节点和后面的节点比较
        //返回false：交换，返回true 不交换
//        if（isParent）{
//            if（rhs.isParent）{
//                res = id >= rhs.id;
//            }else{
//                res = false;//交换
//            }
//        }else{
//            if（rhs.isParent）{
//                res = true; //不交换
//            }else{
//                res = id >= rhs.id;;//交换
//            }
//        }
        Bit bitTrue(true);
        Bit bitFalse(false);
        Bit cond1 = this->isParent & rhs.isParent;
        Bit cond2 = (!this->isParent) & (!rhs.isParent);
        Bit res_temp = this->id >= rhs.id;

        //Bit res1 = IF(cond1, res_temp, bitFalse);
        Bit res1 = bitFalse.select(cond1, res_temp);
        //Bit res2 = IF(cond2, res_temp, bitTrue);
        Bit res2 = bitTrue.select(cond2, res_temp);

        //res = IF(isParent, res1, res2);
        Bit res = res2.select(isParent, res1);
        return res;

    }*/


    Bit QDigestNode::equal(const QDigestNode &rhs) const {
        return this->id.equal(rhs.id) & this->c.equal(rhs.c) & (this->isDummy & rhs.isDummy) &
               (this->isParent & rhs.isParent);
    }

    inline int QDigestNode::size() const {
        return id_len + 34;
    }

/*
    template<>
    inline string QDigestNode::reveal<string>(int party) const {
        string res = "(";
        res.append(this->id.reveal<string>(party));
        res.append(",");
        res.append(this->c.reveal<string>(party));
        res.append(",");
        res.append(this->isDummy.reveal<string>(party));
        res.append(",");
        res.append(this->isParent.reveal<string>(party));
        res.append(")");
        return res;
    }
*/
    template<>
    inline string QDigestNode::reveal<string>(int party) const {
        string res = "(";
        if (id_len > 32) {
            res.append(std::to_string(this->id.reveal<int64_t>()));
        } else {
            res.append(std::to_string(this->id.reveal<int32_t>()));
        }
        res.append(",");
        res.append(std::to_string(this->c.reveal<int32_t>()));
        res.append(",");
        res.append(this->isDummy.reveal(PUBLIC) ? "1" : "0");
        res.append(",");
        res.append(this->isParent.reveal(PUBLIC) ? "1" : "0");
        res.append(")");
        return res;
    }

    QDigestNode QDigestNode::operator+(const QDigestNode &rhs) const {
        return QDigestNode(this->id + rhs.id, this->c + rhs.c, this->isDummy | rhs.isDummy,
                           this->isParent | rhs.isParent);
    }

    QDigestNode::QDigestNode(int64_t _id, int _c, bool _is_Dummy, bool _is_Parent, int party) {
        id = Integer(id_len, _id, party);
        c = Integer(32, _c, party);
        isDummy = Bit(_is_Dummy, party);
        isParent = Bit(_is_Parent, party);
    }

    QDigestNode::QDigestNode(const Integer &_id, const Integer &_c, const Bit &_isDummy, const Bit &_isParent) :
            id(_id),
            c(_c),
            isDummy(_isDummy),
            isParent(_isParent) {}

    QDigestNode::~QDigestNode() {
    }

    QDigestNode::QDigestNode() = default;
}

#endif //EMP_SH2PC_Q_DIGEST_NODE_H
