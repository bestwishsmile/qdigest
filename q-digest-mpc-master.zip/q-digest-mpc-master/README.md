# q-digest-mpc
## 准备
需要先安装 emp-toolkit 套件中的 emp-tool, emp-ot, emp-sh2pc 才能使用
## 使用方式
```
#git clone https://github.com/JinHongjian545/q-digest-mpc.git
#cd q-digest-mpc
#cmake .
#make
```

